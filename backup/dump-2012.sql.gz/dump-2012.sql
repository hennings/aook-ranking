-- MySQL dump 10.11
--
-- Host: localhost    Database: hs_aook_ranking
-- ------------------------------------------------------
-- Server version	5.0.96-0ubuntu3

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `class`
--

DROP TABLE IF EXISTS `class`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `class` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `class`
--

LOCK TABLES `class` WRITE;
/*!40000 ALTER TABLE `class` DISABLE KEYS */;
INSERT INTO `class` VALUES (1,'H13-14'),(2,'D13-14'),(3,'H15-16'),(4,'D15-16');
/*!40000 ALTER TABLE `class` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `person`
--

DROP TABLE IF EXISTS `person`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `person` (
  `id` int(11) NOT NULL auto_increment,
  `family_name` varchar(255) default NULL,
  `given_name` varchar(255) default NULL,
  `club` varchar(255) default NULL,
  `club_id` int(11) default NULL,
  `created` timestamp NOT NULL default CURRENT_TIMESTAMP on update CURRENT_TIMESTAMP,
  `eventor_id` int(11) default NULL,
  `duplicate_of` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=172 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `person`
--

LOCK TABLES `person` WRITE;
/*!40000 ALTER TABLE `person` DISABLE KEYS */;
INSERT INTO `person` VALUES (1,'Faller RÃ¥heim','Ã…shild','OK Ã˜st',258,'2012-05-17 18:50:57',5724,119),(2,'Winsnes Nordhagen','Rannveig','Ã…s-UMB Orientering',402,'2012-05-14 21:27:02',2337,NULL),(3,'Smeby','Henriette','Nydalens SK',245,'2012-05-14 21:27:02',2294,NULL),(4,'Woxholth','Nora SynnÃ¸ve','Asker Skiklubb',26,'2012-05-14 21:27:03',4280,NULL),(5,'WislÃ¸ff','Margrethe','Asker Skiklubb',26,'2012-05-14 21:27:03',4011,NULL),(6,'Markussen','Fanni JauhojÃ¤rvi','Asker Skiklubb',26,'2012-05-14 21:27:03',3866,NULL),(7,'Hodt','Line Wegner','Fossum IF',80,'2012-05-14 21:27:03',2914,NULL),(8,'Rapp','Synne Eide','Raumar Orientering',281,'2012-05-14 21:27:04',3456,NULL),(9,'Iversen','Sofie SkyttersÃ¦ter','Heming Orientering',114,'2012-05-14 21:27:04',2855,NULL),(10,'Helland-Hansen','Anniken','IL Tyrving',163,'2012-05-14 21:27:04',2749,NULL),(11,'Fleisje','Ingvild C.','Nittedal OL',236,'2012-05-14 21:27:04',5298,NULL),(12,'OlsbÃ¸','Maria','Ã˜stmarka OK',388,'2012-05-14 21:27:05',3826,NULL),(13,'HÃ¦stad BjÃ¸rnstad','Victoria','Fossum IF',80,'2012-05-14 21:27:05',4000,NULL),(14,'Sikkeland','Oda','IL Tyrving',163,'2012-05-14 21:27:05',2706,NULL),(15,'Ahlsand','Ingvil','Nydalens SK',245,'2012-05-14 21:27:05',2364,NULL),(16,'SkjÃ¦rstein','Synne','IL Tyrving',163,'2012-05-14 21:27:06',4065,NULL),(17,'Aaslund','Ingrid','Fet OL',71,'2012-05-14 21:27:06',1894,NULL),(18,'Bergan','Ã…se','Nydalens SK',245,'2012-05-14 21:27:06',3729,NULL),(19,'Graffer','Nora','Ã˜stmarka OK',388,'2012-05-14 21:27:06',3819,NULL),(20,'Haltia','Thea Feiring','IL Tyrving',163,'2012-05-14 21:27:07',2646,NULL),(21,'Treekrem','Marie','Ã…s-UMB Orientering',402,'2012-05-14 21:27:07',5608,NULL),(22,'Westgaard','Eline Lund','Oppsal Orientering',268,'2012-05-14 21:27:07',4080,NULL),(23,'Bakke','Julie','Fossum IF',80,'2012-05-14 21:27:07',3992,NULL),(24,'Sandberg','Maiken','Nydalens SK',245,'2012-05-14 21:27:08',4090,NULL),(25,'Grandal','Hanne','IL Tyrving',163,'2012-05-14 21:27:09',365,NULL),(26,'RÃ¸stadsand','Synne Eikeland','Nydalens SK',245,'2012-05-14 21:27:09',2293,NULL),(27,'Ã˜derud Vatne','Johanne','BÃ¦kkelagets SK',32,'2012-05-14 21:27:10',7621,NULL),(28,'Vollset','Hedvig','Heming Orientering',114,'2012-05-14 21:27:10',6273,NULL),(29,'Kvam','Eirin','IL Tyrving',163,'2012-05-14 21:27:10',6274,NULL),(30,'Sommerstad Vee','Emilie','IL Tyrving',163,'2012-05-14 21:27:11',2797,NULL),(31,'NjÃ¥stein','Stine','IL Tyrving',163,'2012-05-14 21:27:11',1820,NULL),(32,'Paulsen','Emma Eithun','Nittedal OL',236,'2012-05-14 21:27:11',4677,NULL),(33,'Ramstad','Marthe','Fet OL',71,'2012-05-14 21:27:11',4107,NULL),(34,'Gulbrandsen','Vegard','Asker Skiklubb',26,'2012-05-14 21:27:23',1673,NULL),(35,'BrÃ¥ten','Ola LÃ¸vald','Asker Skiklubb',26,'2012-05-14 21:27:23',2616,NULL),(36,'Halden','Gjermund TÃ¸rnqvist','Nydalens SK',245,'2012-05-14 21:27:24',3164,NULL),(37,'Haga','Anders','Raumar Orientering',281,'2012-05-14 21:27:24',3312,NULL),(38,'Jonsson','Elias','Nydalens SK',245,'2012-05-14 21:27:24',2114,NULL),(39,'Hjermstad','Erling','Fossum IF',80,'2012-05-14 21:27:24',3446,NULL),(40,'KamsvÃ¥g','Styrk Hundseid','IL Tyrving',163,'2012-05-14 21:27:25',2641,NULL),(41,'Holo','Tarjei','Fossum IF',80,'2012-05-14 21:27:25',3979,NULL),(42,'Heir','Martin Borge','Fossum IF',80,'2012-05-14 21:27:25',4131,NULL),(43,'Gravir','Eivind Ã˜fsthus','Asker Skiklubb',26,'2012-05-14 21:27:25',5739,NULL),(44,'Melsom','Einar','Fossum IF',80,'2012-05-14 21:27:26',3886,NULL),(45,'Fosser','Kasper','Heming Orientering',114,'2012-05-14 21:27:26',8645,NULL),(46,'KrÃ¼ger','Espen Hegstad','Nydalens SK',245,'2012-05-14 21:27:26',2169,NULL),(47,'Rogne','Anders','Nittedal OL',236,'2012-05-14 21:27:26',5802,NULL),(48,'LunÃ¸e','Sam','Nydalens SK',245,'2012-05-14 21:27:27',2303,NULL),(49,'LÃ¸vli','BjÃ¸rnar','Asker Skiklubb',26,'2012-05-14 21:27:27',1718,NULL),(50,'Skei','Emil Morgenlie','Nydalens SK',245,'2012-05-14 21:27:27',2122,NULL),(51,'Breivik','Eirik Langedal','Nydalens SK',245,'2012-05-14 21:27:28',3259,NULL),(52,'Ryan','Ola Tandberg','Asker Skiklubb',26,'2012-05-14 21:27:28',4018,NULL),(53,'Liland','Lukas','Nydalens SK',245,'2012-05-14 21:27:28',2291,NULL),(54,'Hole','Alexander Skeppland','Nydalens SK',245,'2012-05-14 21:27:28',88,NULL),(55,'Grevstad','Oskar','Fossum IF',80,'2012-05-14 21:27:29',3267,NULL),(56,'Reinseth','Johannes Finne','Nydalens SK',245,'2012-05-14 21:27:29',4265,NULL),(57,'Kvisle','Sjur','Asker Skiklubb',26,'2012-05-14 21:27:29',2710,NULL),(58,'Tandberg','Jostein','Nydalens SK',245,'2012-05-14 21:27:29',2586,NULL),(59,'Ã˜yen','Halvor','Asker Skiklubb',26,'2012-05-14 21:27:29',3968,NULL),(60,'Dyrstad','Sigurd','Nydalens SK',245,'2012-05-14 21:27:30',2790,NULL),(61,'BarkenÃ¦s','JÃ¸rgen Kjos','Fet OL',71,'2012-05-14 21:27:30',5830,NULL),(62,'Langaas','Anders','Nydalens SK',245,'2012-05-14 21:27:30',2081,NULL),(63,'Skotte','Martin Andresen','Fossum IF',80,'2012-05-14 21:27:30',8363,NULL),(64,'Hoveid','Axel','Asker Skiklubb',26,'2012-05-14 21:27:31',3959,NULL),(65,'Ã˜vstedal','HÃ¥kon','Nydalens SK',245,'2012-05-14 21:27:31',2946,NULL),(66,'Heir','Tore','Nydalens SK',245,'2012-05-14 21:27:31',2091,NULL),(67,'Nersten','Ragnar','Fossum IF',80,'2012-05-14 21:27:31',4096,NULL),(68,'Ramberg','Magnus','Ã˜stmarka OK',388,'2012-05-14 21:27:32',3821,NULL),(69,'Hjermstad','Ã˜yvind','Fossum IF',80,'2012-05-14 21:27:32',3445,NULL),(70,'HÃ¦stad BjÃ¸rnstad','Oscar','Fossum IF',80,'2012-05-14 21:27:32',3999,NULL),(71,'SÃ¸nsterudbrÃ¥ten','Karoline','Raumar Orientering',281,'2012-05-14 21:27:44',3356,NULL),(72,'Ahlsand','Anine','Nydalens SK',245,'2012-05-14 21:27:45',2363,NULL),(73,'Fiskum','Astrid','IL Tyrving',163,'2012-05-14 21:27:45',1063,NULL),(74,'Nersten','Marit','Fossum IF',80,'2012-05-14 21:27:45',3851,NULL),(75,'Gravir','Selma Ã˜fsthus','Asker Skiklubb',26,'2012-05-14 21:27:45',4804,NULL),(76,'Tandrevold','Ingrid Landmark','Fossum IF',80,'2012-05-14 21:27:46',4070,NULL),(77,'Grandal','Siri','IL Tyrving',163,'2012-05-14 21:27:46',362,NULL),(78,'Haltia','Ida Feiring','IL Tyrving',163,'2012-05-14 21:27:46',2644,NULL),(79,'Wang','Ingvild','Lillomarka OL',203,'2012-05-14 21:27:46',3929,NULL),(80,'Hjermstad','Ragnhild','Fossum IF',80,'2012-05-14 21:27:47',3437,NULL),(81,'Bakken','Stine Madslien','Nydalens SK',245,'2012-05-14 21:27:47',2120,NULL),(82,'BrÃ¥ten','Tiril Ruud','Raumar Orientering',281,'2012-05-14 21:27:47',3354,NULL),(83,'Bakke','Sara Angell','Lillomarka OL',203,'2012-05-14 21:27:48',3435,NULL),(84,'HÃ¸iland','Christine Williksen','Fossum IF',80,'2012-05-14 21:27:48',7550,NULL),(85,'Aarrestad','Anniken','Nydalens SK',245,'2012-05-14 21:27:48',3249,NULL),(86,'Bjergaard','Karen','Nydalens SK',245,'2012-05-14 21:27:48',2672,NULL),(87,'Ã˜degaard','Thea-Elise','Fossum IF',80,'2012-05-14 21:27:49',3945,NULL),(88,'Sandberg','Stina','Nydalens SK',245,'2012-05-14 21:27:49',4089,NULL),(89,'Flatebakken','Synne Nesheim','IL Tyrving',163,'2012-05-14 21:27:49',3269,NULL),(90,'Hagen','Emilie Johanne','Raumar Orientering',281,'2012-05-14 21:27:49',3318,NULL),(91,'Blindheim','Kristin','Lillomarka OL',203,'2012-05-14 21:27:50',3753,NULL),(92,'Fossum Rye','Elin','Asker Skiklubb',26,'2012-05-14 21:27:50',2612,NULL),(93,'Dirro','Marian','MÃ¥ren OK',227,'2012-05-14 21:27:50',4154,NULL),(94,'LÃ¸vald','Kaja BrÃ¥ten','Asker Skiklubb',26,'2012-05-14 21:27:51',3694,NULL),(95,'Brekke','Kristin','Lillomarka OL',203,'2012-05-14 21:27:51',3399,NULL),(96,'Heir','Kjersti','Nydalens SK',245,'2012-05-14 21:27:51',4304,NULL),(97,'Paulsen','Oda Eithun','Nittedal OL',236,'2012-05-14 21:27:51',4678,NULL),(98,'Norderud','Nanna','IL Tyrving',163,'2012-05-14 21:27:51',3880,NULL),(99,'MÃ¸lnvik','Elias T.','Fossum IF',80,'2012-05-14 21:28:02',3606,NULL),(100,'Lillevold','Olai Stensland','Ã…s-UMB Orientering',402,'2012-05-14 21:28:03',576,NULL),(101,'Kollerud','Steinar','Lillomarka OL',203,'2012-05-14 21:28:03',4893,NULL),(102,'Kvisle','Erland','Asker Skiklubb',26,'2012-05-14 21:28:03',2709,NULL),(103,'Arnesen','Ulrik Astrup','Heming Orientering',114,'2012-05-14 21:28:03',2419,NULL),(104,'Eijsink','Henrik','Ã…s-UMB Orientering',402,'2012-05-14 21:28:04',709,NULL),(105,'Tandberg','VebjÃ¸rn','Nydalens SK',245,'2012-05-14 21:28:04',2585,NULL),(106,'StÃ¸rmer','Oskar','Fossum IF',80,'2012-05-14 21:28:04',3379,NULL),(107,'Wiklund','Elias','Nydalens SK',245,'2012-05-14 21:28:04',2145,NULL),(108,'Weidemann','JÃ¸rgen','Nydalens SK',245,'2012-05-14 21:28:04',2279,NULL),(109,'Aaslund','BjÃ¸rn AndrÃ©','Fet OL',71,'2012-05-14 21:28:05',1891,NULL),(110,'Hoel','Amund','Raumar Orientering',281,'2012-05-14 21:28:05',3369,NULL),(111,'Brende','Ola','Fossum IF',80,'2012-05-14 21:28:05',8665,NULL),(112,'KamsvÃ¥g','Skjalg Hundseid','IL Tyrving',163,'2012-05-14 21:28:05',2642,NULL),(113,'Marcussen','Andreas','Asker Skiklubb',26,'2012-05-14 21:28:06',4140,NULL),(114,'Karpenka','Dzmitry','Asker Skiklubb',26,'2012-05-14 21:28:06',4794,NULL),(115,'Rogne','Lars Gustav','Nittedal OL',236,'2012-05-14 21:28:06',4922,NULL),(116,'Swensen','Eilif Tandberg','Asker Skiklubb',26,'2012-05-14 21:28:06',4968,NULL),(117,'Hodt','Erik Wegner','Fossum IF',80,'2012-05-14 21:28:07',4271,NULL),(118,'Melsom','Sigurd','Fossum IF',80,'2012-05-14 21:28:07',3849,NULL),(119,'Faller RÃ¥heim','Ã…shild','Fet OL',71,'2012-05-14 21:28:16',9534,NULL),(120,'Karlsen','Anniken E.','Oppsal Orientering',268,'2012-05-14 21:28:17',7559,NULL),(121,'Engebretsen','Martine','Heming Orientering',114,'2012-05-14 21:28:18',7681,NULL),(122,'Haver','Mina','Lillomarka OL',203,'2012-05-14 21:28:19',7697,NULL),(123,'Horten','Ylva','Lillomarka OL',203,'2012-05-14 21:28:20',7733,NULL),(124,'Langebeck','Andrine','Kolbotn og Skimt OL',181,'2012-05-14 21:28:21',6939,NULL),(125,'Masdal','Ingrid','Lillomarka OL',203,'2012-05-14 21:28:21',5958,NULL),(126,'BÃ¥rdsen','Louise MarÃ¸y','Heming Orientering',114,'2012-05-14 21:28:21',6644,NULL),(127,'FlÃ¥gen','BjÃ¸rn Anders','Heming Orientering',114,'2012-05-14 21:28:30',5633,NULL),(128,'Johansen','Thomas Haarr','Oppsal Orientering',268,'2012-05-14 21:28:30',6869,NULL),(129,'Hoff','Fredrik Ramstad','Fossum IF',80,'2012-05-14 21:28:33',4009,NULL),(130,'Thorstensen','Lavran','Oppsal Orientering',268,'2012-05-14 21:28:33',4060,NULL),(131,'BÃ¸e','Audun Rognerud','Fossum IF',80,'2012-05-14 21:28:33',4123,NULL),(132,'Sedin','Andreas','Raumar Orientering',281,'2012-05-14 21:28:34',9419,NULL),(133,'Haugen','Mads Aanes','Frogner IL',83,'2012-05-14 21:28:34',3438,NULL),(134,'Haugmo','Sindre Rolfsen','Heming Orientering',114,'2012-05-14 21:28:34',7795,NULL),(135,'Risebrobakken','Lars','Raumar Orientering',281,'2012-05-14 21:28:35',4435,NULL),(136,'Hjermstad','HÃ¥vard','Fossum IF',80,'2012-05-14 21:28:35',3447,NULL),(137,'Haugmo','Erik Rolfsen','Heming Orientering',114,'2012-05-14 21:28:36',7796,NULL),(138,'Westly','Johan Teodor','Asker Skiklubb',26,'2012-05-14 21:28:36',4064,NULL),(139,'EdstrÃ¸m','Ole Martin','Oppsal Orientering',268,'2012-05-14 21:28:36',5680,NULL),(140,'Hygen','Hans Kristian Stubban','Ã˜stmarka OK',388,'2012-05-14 21:28:37',4291,NULL),(141,'Helland-Hansen','Kristin','IL Tyrving',163,'2012-05-14 21:28:45',2746,NULL),(142,'Grandal','Siri','IL Tyrving',163,'2012-05-17 18:50:37',3677,77),(143,'Holen','Ragnhild Marie','Ã˜stmarka OK',388,'2012-05-14 21:28:46',9621,NULL),(144,'NergÃ¥rd','Ingrid Nytun','Nittedal OL',236,'2012-05-14 21:28:47',4956,NULL),(145,'Wigaard','Are','Oppsal Orientering',268,'2012-05-14 21:28:56',2435,NULL),(146,'Moe','Herman','Fet OL',71,'2012-05-14 21:28:57',4098,NULL),(147,'BjÃ¸rhovde','Runar','BÃ¦kkelagets SK',32,'2012-05-14 21:28:57',5990,NULL),(148,'VÃ¥gen','Magnus Rokne','Nydalens SK',245,'2012-05-14 21:28:58',4046,NULL),(149,'Wigaard','Endre','Oppsal Orientering',268,'2012-05-14 21:28:58',1647,NULL),(150,'WÃ¸lneberg','Magnus','IL Tyrving',163,'2012-05-14 21:28:59',2684,NULL),(151,'Jansson','Robin Bergane','Siggerud IL',310,'2012-05-14 21:28:59',7825,NULL),(152,'Martinussen','Karsten','Fossum IF',80,'2012-05-14 21:28:59',5816,NULL),(153,'Johansen','Mahtias','Siggerud IL',310,'2012-05-14 21:29:00',7786,NULL),(154,'Helmersen','Helge Nikolai','Fet OL',71,'2012-05-14 21:29:00',5775,NULL),(155,'Martinsen','Claus','Heming Orientering',114,'2012-05-14 21:29:00',1258,NULL),(156,'Resell','Ã…smund Aamodt','Nydalens SK',245,'2012-05-14 21:29:00',2597,NULL),(157,'Fjellang','Georg Balke','Nydalens SK',245,'2012-05-14 21:29:00',3136,NULL),(158,'Malmei','Hannah','Nydalens SK',245,'2012-05-20 16:00:46',6139,NULL),(159,'Arnesen','Nikolai Jones','Heming Orientering',114,'2012-05-20 16:01:05',6298,NULL),(160,'Onstad','Martin Ekeli','Oppsal Orientering',268,'2012-05-20 16:01:06',1788,NULL),(161,'Kavlie','Trym LÃ¸vseth','Heming Orientering',114,'2012-05-20 16:01:07',8465,NULL),(162,'Eidem','Sebastian','Heming Orientering',114,'2012-05-20 16:01:07',7654,NULL),(163,'Grundt','Anders','Heming Orientering',114,'2012-05-20 16:01:07',9862,NULL),(164,'Lian','Sindre Vestengen','Lillomarka OL',203,'2012-05-20 16:01:08',5881,NULL),(165,'Aasheim','Knut','Oppsal Orientering',268,'2012-05-20 16:02:26',4069,NULL),(166,'Gjemdal','Kristian Lampe','Heming Orientering',114,'2012-05-20 16:02:26',4895,NULL),(167,'RÃ¸dnes','Ludvig Andreas BaugstÃ¸','Oppsal Orientering',268,'2012-05-20 16:02:28',3083,NULL),(168,'LÃ¦gran','Johanne','Nydalens SK',245,'2012-05-20 16:04:37',2720,NULL),(169,'Malmei','Vilde','Nydalens SK',245,'2012-05-20 16:04:38',6138,NULL),(170,'Eik Haave','Sunniva','Oppsal Orientering',268,'2012-05-20 16:04:39',6240,NULL),(171,'LÃ¦gran','Oda','Nydalens SK',245,'2012-05-20 16:04:39',2721,NULL);
/*!40000 ALTER TABLE `person` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `race`
--

DROP TABLE IF EXISTS `race`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `race` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  `race_date` date default NULL,
  `season` int(4) default NULL,
  `eventor_id` int(11) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `race`
--

LOCK TABLES `race` WRITE;
/*!40000 ALTER TABLE `race` DISABLE KEYS */;
INSERT INTO `race` VALUES (1,'Lordagskjappen','2012-04-28',2012,467),(2,'Kolbotn','2012-05-13',2012,880),(3,'KVM','2012-05-20',2012,NULL),(4,'Lordagskjappen','2013-04-27',2013,2536);
/*!40000 ALTER TABLE `race` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `result`
--

DROP TABLE IF EXISTS `result`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `result` (
  `id` int(11) NOT NULL auto_increment,
  `race_id` int(11) default NULL,
  `person_id` int(11) default NULL,
  `time` varchar(255) default NULL,
  `status` varchar(20) default NULL,
  `points` float default NULL,
  `class` varchar(30) default NULL,
  `time_sec` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `race_id` (`race_id`),
  KEY `person_id` (`person_id`)
) ENGINE=InnoDB AUTO_INCREMENT=381 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `result`
--

LOCK TABLES `result` WRITE;
/*!40000 ALTER TABLE `result` DISABLE KEYS */;
INSERT INTO `result` VALUES (1,1,119,'26:47','OK',1005.51,'D13-14',1607),(2,1,2,'26:49','OK',1003.45,'D13-14',1609),(3,1,3,'27:01','OK',991.041,'D13-14',1621),(4,1,4,'28:46','OK',882.503,'D13-14',1726),(5,1,5,'29:17','OK',850.458,'D13-14',1757),(6,1,6,'30:49','OK',755.358,'D13-14',1849),(7,1,7,'31:54','OK',688.168,'D13-14',1914),(8,1,8,'32:42','OK',638.55,'D13-14',1962),(9,1,9,'35:35','OK',459.72,'D13-14',2135),(10,1,10,'35:56','OK',438.013,'D13-14',2156),(11,1,11,'36:22','OK',411.136,'D13-14',2182),(12,1,12,'36:29','OK',403.9,'D13-14',2189),(13,1,13,'36:56','OK',375.991,'D13-14',2216),(14,1,14,'37:51','OK',319.137,'D13-14',2271),(15,1,15,'38:33','OK',275.722,'D13-14',2313),(16,1,16,'38:49','OK',259.183,'D13-14',2329),(17,1,17,'38:57','OK',250.913,'D13-14',2337),(18,1,18,'41:18','OK',105.162,'D13-14',2478),(19,1,19,'42:17','OK',44.1734,'D13-14',2537),(20,1,20,'42:23','OK',37.9712,'D13-14',2543),(21,1,21,'47:36','OK',0,'D13-14',2856),(22,1,22,'48:17','OK',0,'D13-14',2897),(23,1,23,'48:30','OK',0,'D13-14',2910),(24,1,24,'48:41','OK',0,'D13-14',2921),(25,1,25,'49:11','OK',0,'D13-14',2951),(26,1,26,'50:54','OK',0,'D13-14',3054),(27,1,27,'57:22','OK',0,'D13-14',3442),(28,1,28,'57:49','OK',0,'D13-14',3469),(29,1,29,'96:53','OK',0,'D13-14',5813),(30,1,30,'','Cancelled',NULL,'D13-14',0),(31,1,31,'','Cancelled',NULL,'D13-14',0),(32,1,32,'31:47','Disqualified',NULL,'D13-14',1907),(33,1,33,'49:01','Disqualified',NULL,'D13-14',2941),(34,1,34,'21:18','OK',1140.15,'H13-14',1278),(35,1,35,'23:52','OK',956.203,'H13-14',1432),(36,1,36,'24:36','OK',903.647,'H13-14',1476),(37,1,37,'25:29','OK',840.341,'H13-14',1529),(38,1,38,'25:42','OK',824.813,'H13-14',1542),(39,1,39,'26:34','OK',762.701,'H13-14',1594),(40,1,40,'27:04','OK',726.867,'H13-14',1624),(41,1,41,'27:31','OK',694.617,'H13-14',1651),(42,1,42,'27:39','OK',685.061,'H13-14',1659),(43,1,43,'27:44','OK',679.089,'H13-14',1664),(44,1,44,'28:52','OK',597.866,'H13-14',1732),(45,1,45,'29:13','OK',572.782,'H13-14',1753),(46,1,46,'29:41','OK',539.337,'H13-14',1781),(47,1,47,'30:40','OK',468.864,'H13-14',1840),(48,1,48,'30:56','OK',449.753,'H13-14',1856),(49,1,49,'31:50','OK',385.252,'H13-14',1910),(50,1,50,'33:00','OK',301.64,'H13-14',1980),(51,1,51,'35:14','OK',141.583,'H13-14',2114),(52,1,52,'35:43','OK',106.944,'H13-14',2143),(53,1,53,'35:47','OK',102.166,'H13-14',2147),(54,1,54,'36:39','OK',40.0541,'H13-14',2199),(55,1,55,'37:28','OK',0,'H13-14',2248),(56,1,56,'37:30','OK',0,'H13-14',2250),(57,1,57,'37:31','OK',0,'H13-14',2251),(58,1,58,'38:56','OK',0,'H13-14',2336),(59,1,59,'40:45','OK',0,'H13-14',2445),(60,1,60,'41:49','OK',0,'H13-14',2509),(61,1,61,'42:09','OK',0,'H13-14',2529),(62,1,62,'44:15','OK',0,'H13-14',2655),(63,1,63,'71:03','OK',0,'H13-14',4263),(64,1,64,'','Cancelled',NULL,'H13-14',0),(65,1,65,'','Cancelled',NULL,'H13-14',0),(66,1,66,'','Cancelled',NULL,'H13-14',0),(67,1,67,'','Cancelled',NULL,'H13-14',0),(68,1,68,'','Cancelled',NULL,'H13-14',0),(69,1,69,'26:59','Disqualified',NULL,'H13-14',1619),(70,1,70,'51:59','Disqualified',NULL,'H13-14',3119),(71,1,71,'45:31','OK',1021.88,'D15-16',2731),(72,1,72,'46:22','OK',991.167,'D15-16',2782),(73,1,73,'46:29','OK',986.951,'D15-16',2789),(74,1,74,'47:41','OK',943.588,'D15-16',2861),(75,1,75,'49:05','OK',892.998,'D15-16',2945),(76,1,76,'49:29','OK',878.543,'D15-16',2969),(77,1,77,'49:37','OK',873.725,'D15-16',2977),(78,1,78,'51:39','OK',800.249,'D15-16',3099),(79,1,79,'51:53','OK',791.817,'D15-16',3113),(80,1,80,'51:54','OK',791.215,'D15-16',3114),(81,1,81,'52:25','OK',772.545,'D15-16',3145),(82,1,82,'52:45','OK',760.499,'D15-16',3165),(83,1,83,'54:33','OK',695.455,'D15-16',3273),(84,1,84,'54:34','OK',694.853,'D15-16',3274),(85,1,85,'54:46','OK',687.625,'D15-16',3286),(86,1,86,'58:42','OK',545.491,'D15-16',3522),(87,1,87,'58:58','OK',535.855,'D15-16',3538),(88,1,88,'59:03','OK',532.844,'D15-16',3543),(89,1,89,'59:34','OK',514.173,'D15-16',3574),(90,1,90,'59:35','OK',513.571,'D15-16',3575),(91,1,91,'61:10','OK',456.356,'D15-16',3670),(92,1,92,'65:41','OK',293.142,'D15-16',3941),(93,1,93,'78:29','OK',0,'D15-16',4709),(94,1,94,'','Cancelled',NULL,'D15-16',0),(95,1,95,'','Cancelled',NULL,'D15-16',0),(96,1,96,'','Cancelled',NULL,'D15-16',0),(97,1,97,'44:52','Disqualified',NULL,'D15-16',2692),(98,1,98,'773:00','Disqualified',NULL,'D15-16',46380),(99,1,99,'35:47','OK',1048.49,'H15-16',2147),(100,1,100,'37:18','OK',979.901,'H15-16',2238),(101,1,101,'37:29','OK',971.611,'H15-16',2249),(102,1,102,'38:11','OK',939.956,'H15-16',2291),(103,1,103,'42:19','OK',753.04,'H15-16',2539),(104,1,104,'43:09','OK',715.355,'H15-16',2589),(105,1,105,'44:12','OK',667.873,'H15-16',2652),(106,1,106,'44:13','OK',667.119,'H15-16',2653),(107,1,107,'45:15','OK',620.39,'H15-16',2715),(108,1,108,'47:03','OK',538.991,'H15-16',2823),(109,1,109,'49:16','OK',438.75,'H15-16',2956),(110,1,110,'54:01','OK',223.947,'H15-16',3241),(111,1,111,'55:26','OK',159.883,'H15-16',3326),(112,1,112,'58:29','OK',21.9576,'H15-16',3509),(113,1,113,'59:14','OK',0,'H15-16',3554),(114,1,114,'60:21','OK',0,'H15-16',3621),(115,1,115,'62:43','OK',0,'H15-16',3763),(116,1,116,'62:54','OK',0,'H15-16',3774),(117,1,117,'81:23','OK',0,'H15-16',4883),(118,1,118,'45:01','Disqualified',NULL,'H15-16',2701),(119,2,2,'19:39','OK',1049.38,'D13-14',1179),(120,2,7,'20:13','OK',1002.74,'D13-14',1213),(121,2,9,'20:53','OK',947.874,'D13-14',1253),(122,2,31,'20:55','OK',945.13,'D13-14',1255),(123,2,5,'21:37','OK',887.517,'D13-14',1297),(124,2,119,'22:19','OK',829.904,'D13-14',1339),(125,2,12,'23:05','OK',766.804,'D13-14',1385),(126,2,4,'23:41','OK',717.421,'D13-14',1421),(127,2,6,'23:54','OK',699.589,'D13-14',1434),(128,2,3,'24:26','OK',655.693,'D13-14',1466),(129,2,120,'25:09','OK',596.708,'D13-14',1509),(130,2,10,'25:14','OK',589.849,'D13-14',1514),(131,2,16,'25:27','OK',572.016,'D13-14',1527),(132,2,13,'26:02','OK',524.005,'D13-14',1562),(133,2,8,'26:35','OK',478.738,'D13-14',1595),(134,2,32,'26:38','OK',474.623,'D13-14',1598),(135,2,121,'27:06','OK',436.214,'D13-14',1626),(136,2,17,'27:57','OK',366.255,'D13-14',1677),(137,2,21,'28:24','OK',329.218,'D13-14',1704),(138,2,14,'31:59','OK',34.2936,'D13-14',1919),(139,2,11,'32:04','OK',27.4348,'D13-14',1924),(140,2,122,'32:18','OK',8.23045,'D13-14',1938),(141,2,18,'32:48','OK',0,'D13-14',1968),(142,2,26,'33:03','OK',0,'D13-14',1983),(143,2,123,'33:50','OK',0,'D13-14',2030),(144,2,23,'34:18','OK',0,'D13-14',2058),(145,2,20,'35:56','OK',0,'D13-14',2156),(146,2,25,'37:02','OK',0,'D13-14',2222),(147,2,24,'37:42','OK',0,'D13-14',2262),(148,2,27,'45:05','OK',0,'D13-14',2705),(149,2,124,'46:45','OK',0,'D13-14',2805),(150,2,125,'47:10','OK',0,'D13-14',2830),(151,2,28,'','Cancelled',NULL,'D13-14',0),(152,2,126,'','Cancelled',NULL,'D13-14',0),(153,2,33,'37:41','Disqualified',NULL,'D13-14',2261),(154,2,22,'52:19','Disqualified',NULL,'D13-14',3139),(155,2,36,'19:31','OK',1087.22,'H13-14',1171),(156,2,41,'20:48','OK',983.365,'H13-14',1248),(157,2,39,'21:28','OK',929.413,'H13-14',1288),(158,2,38,'21:33','OK',922.669,'H13-14',1293),(159,2,37,'21:47','OK',903.786,'H13-14',1307),(160,2,69,'22:14','OK',867.368,'H13-14',1334),(161,2,40,'23:35','OK',758.115,'H13-14',1415),(162,2,48,'23:44','OK',745.976,'H13-14',1424),(163,2,127,'23:51','OK',736.534,'H13-14',1431),(164,2,128,'27:19','OK',455.984,'H13-14',1639),(165,2,45,'27:30','OK',441.147,'H13-14',1650),(166,2,68,'27:42','OK',424.962,'H13-14',1662),(167,2,62,'27:50','OK',414.171,'H13-14',1670),(168,2,49,'28:10','OK',387.195,'H13-14',1690),(169,2,50,'28:24','OK',368.312,'H13-14',1704),(170,2,58,'28:52','OK',330.546,'H13-14',1732),(171,2,42,'29:23','OK',288.733,'H13-14',1763),(172,2,46,'29:25','OK',286.035,'H13-14',1765),(173,2,43,'29:36','OK',271.199,'H13-14',1776),(174,2,55,'31:04','OK',152.504,'H13-14',1864),(175,2,129,'31:30','OK',117.435,'H13-14',1890),(176,2,54,'31:41','OK',102.599,'H13-14',1901),(177,2,51,'32:26','OK',41.9027,'H13-14',1946),(178,2,130,'34:05','OK',0,'H13-14',2045),(179,2,131,'38:01','OK',0,'H13-14',2281),(180,2,61,'42:11','OK',0,'H13-14',2531),(181,2,132,'42:23','OK',0,'H13-14',2543),(182,2,47,'42:30','OK',0,'H13-14',2550),(183,2,133,'52:52','OK',0,'H13-14',3172),(184,2,134,'53:33','OK',0,'H13-14',3213),(185,2,64,'','Cancelled',NULL,'H13-14',0),(186,2,135,'','Cancelled',NULL,'H13-14',0),(187,2,66,'','Cancelled',NULL,'H13-14',0),(188,2,57,'','Cancelled',NULL,'H13-14',0),(189,2,136,'','Cancelled',NULL,'H13-14',0),(190,2,44,'26:31','Disqualified',NULL,'H13-14',1591),(191,2,70,'35:02','Disqualified',NULL,'H13-14',2102),(192,2,137,'35:59','Disqualified',NULL,'H13-14',2159),(193,2,138,'37:34','Disqualified',NULL,'H13-14',2254),(194,2,139,'47:49','Disqualified',NULL,'H13-14',2869),(195,2,140,'53:04','Disqualified',NULL,'H13-14',3184),(196,2,71,'24:33','OK',1062.09,'D15-16',1473),(197,2,94,'25:49','OK',979.303,'D15-16',1549),(198,2,95,'26:08','OK',958.606,'D15-16',1568),(199,2,80,'26:51','OK',911.765,'D15-16',1611),(200,2,81,'27:20','OK',880.174,'D15-16',1640),(201,2,73,'27:38','OK',860.566,'D15-16',1658),(202,2,76,'27:38','OK',860.566,'D15-16',1658),(203,2,75,'27:59','OK',837.691,'D15-16',1679),(204,2,89,'28:11','OK',824.619,'D15-16',1691),(205,2,74,'28:31','OK',802.832,'D15-16',1711),(206,2,141,'29:23','OK',746.187,'D15-16',1763),(207,2,83,'29:42','OK',725.49,'D15-16',1782),(208,2,77,'30:01','OK',704.793,'D15-16',1801),(209,2,91,'30:18','OK',686.275,'D15-16',1818),(210,2,88,'30:51','OK',650.327,'D15-16',1851),(211,2,143,'31:00','OK',640.523,'D15-16',1860),(212,2,78,'31:52','OK',583.878,'D15-16',1912),(213,2,82,'31:55','OK',580.61,'D15-16',1915),(214,2,86,'33:57','OK',447.712,'D15-16',2037),(215,2,144,'38:10','OK',172.113,'D15-16',2290),(216,2,85,'38:22','OK',159.041,'D15-16',2302),(217,2,93,'49:14','OK',0,'D15-16',2954),(218,2,84,'','Cancelled',NULL,'D15-16',0),(219,2,97,'','Cancelled',NULL,'D15-16',0),(220,2,96,'','Cancelled',NULL,'D15-16',0),(221,2,102,'20:53','OK',1047.39,'H15-16',1253),(222,2,100,'21:29','OK',1000.86,'H15-16',1289),(223,2,99,'22:07','OK',951.753,'H15-16',1327),(224,2,101,'22:38','OK',911.691,'H15-16',1358),(225,2,109,'22:42','OK',906.522,'H15-16',1362),(226,2,107,'23:00','OK',883.26,'H15-16',1380),(227,2,110,'23:16','OK',862.583,'H15-16',1396),(228,2,118,'24:40','OK',754.028,'H15-16',1480),(229,2,108,'25:55','OK',657.103,'H15-16',1555),(230,2,104,'26:00','OK',650.642,'H15-16',1560),(231,2,145,'28:48','OK',433.531,'H15-16',1728),(232,2,105,'29:55','OK',346.946,'H15-16',1795),(233,2,115,'30:09','OK',328.853,'H15-16',1809),(234,2,146,'30:37','OK',292.668,'H15-16',1837),(235,2,113,'32:06','OK',177.651,'H15-16',1926),(236,2,147,'32:54','OK',115.62,'H15-16',1974),(237,2,148,'33:08','OK',97.5274,'H15-16',1988),(238,2,149,'33:25','OK',75.5579,'H15-16',2005),(239,2,111,'35:03','OK',0,'H15-16',2103),(240,2,112,'35:07','OK',0,'H15-16',2107),(241,2,103,'35:13','OK',0,'H15-16',2113),(242,2,150,'36:49','OK',0,'H15-16',2209),(243,2,151,'38:01','OK',0,'H15-16',2281),(244,2,152,'40:12','OK',0,'H15-16',2412),(245,2,153,'44:07','OK',0,'H15-16',2647),(246,2,154,'44:12','OK',0,'H15-16',2652),(247,2,155,'','Cancelled',NULL,'H15-16',0),(248,2,156,'','Cancelled',NULL,'H15-16',0),(249,2,157,'46:04','Disqualified',NULL,'H15-16',2764),(250,3,3,'32:59','OK',1078.89,'D13-14',1979),(251,3,2,'34:31','OK',1005.08,'D13-14',2071),(252,3,10,'36:22','OK',916.025,'D13-14',2182),(253,3,7,'36:53','OK',891.153,'D13-14',2213),(254,3,126,'37:21','OK',868.688,'D13-14',2241),(255,3,4,'38:01','OK',836.596,'D13-14',2281),(256,3,6,'38:13','OK',826.968,'D13-14',2293),(257,3,9,'41:07','OK',687.366,'D13-14',2467),(258,3,14,'41:22','OK',675.332,'D13-14',2482),(259,3,120,'41:30','OK',668.913,'D13-14',2490),(260,3,32,'41:37','OK',663.297,'D13-14',2497),(261,3,5,'43:07','OK',591.089,'D13-14',2587),(262,3,12,'43:38','OK',566.217,'D13-14',2618),(263,3,17,'45:56','OK',455.499,'D13-14',2756),(264,3,33,'46:03','OK',449.882,'D13-14',2763),(265,3,122,'46:42','OK',418.592,'D13-14',2802),(266,3,16,'46:43','OK',417.79,'D13-14',2803),(267,3,13,'46:46','OK',415.383,'D13-14',2806),(268,3,18,'47:05','OK',400.139,'D13-14',2825),(269,3,31,'47:31','OK',379.279,'D13-14',2851),(270,3,11,'48:30','OK',331.943,'D13-14',2910),(271,3,121,'51:27','OK',189.934,'D13-14',3087),(272,3,15,'52:41','OK',130.563,'D13-14',3161),(273,3,20,'54:21','OK',50.3316,'D13-14',3261),(274,3,125,'57:17','OK',0,'D13-14',3437),(275,3,22,'57:23','OK',0,'D13-14',3443),(276,3,158,'59:16','OK',0,'D13-14',3556),(277,3,8,'60:14','OK',0,'D13-14',3614),(278,3,27,'','Cancelled',NULL,'D13-14',0),(279,3,25,'','Cancelled',NULL,'D13-14',0),(280,3,26,'','Cancelled',NULL,'D13-14',0),(281,3,21,'5:17','Disqualified',NULL,'D13-14',317),(282,3,119,'12:00','Disqualified',NULL,'D13-14',720),(283,3,34,'27:49','OK',1096.29,'H13-14',1669),(284,3,41,'30:19','OK',955.15,'H13-14',1819),(285,3,35,'30:26','OK',948.564,'H13-14',1826),(286,3,39,'31:03','OK',913.75,'H13-14',1863),(287,3,69,'32:03','OK',857.295,'H13-14',1923),(288,3,42,'32:22','OK',839.418,'H13-14',1942),(289,3,43,'32:52','OK',811.191,'H13-14',1972),(290,3,46,'34:30','OK',718.981,'H13-14',2070),(291,3,48,'34:37','OK',712.395,'H13-14',2077),(292,3,127,'35:00','OK',690.754,'H13-14',2100),(293,3,44,'35:03','OK',687.931,'H13-14',2103),(294,3,40,'35:59','OK',635.24,'H13-14',2159),(295,3,36,'37:38','OK',542.09,'H13-14',2258),(296,3,37,'37:51','OK',529.858,'H13-14',2271),(297,3,47,'37:55','OK',526.095,'H13-14',2275),(298,3,51,'38:23','OK',499.749,'H13-14',2303),(299,3,128,'42:46','OK',252.29,'H13-14',2566),(300,3,61,'44:11','OK',172.312,'H13-14',2651),(301,3,49,'46:16','OK',54.6983,'H13-14',2776),(302,3,54,'48:43','OK',0,'H13-14',2923),(303,3,159,'49:16','OK',0,'H13-14',2956),(304,3,130,'51:23','OK',0,'H13-14',3083),(305,3,137,'52:32','OK',0,'H13-14',3152),(306,3,68,'52:58','OK',0,'H13-14',3178),(307,3,160,'54:23','OK',0,'H13-14',3263),(308,3,139,'55:08','OK',0,'H13-14',3308),(309,3,55,'61:01','OK',0,'H13-14',3661),(310,3,140,'62:04','OK',0,'H13-14',3724),(311,3,131,'62:26','OK',0,'H13-14',3746),(312,3,70,'66:15','OK',0,'H13-14',3975),(313,3,161,'69:02','OK',0,'H13-14',4142),(314,3,162,'76:05','OK',0,'H13-14',4565),(315,3,57,'','Cancelled',NULL,'H13-14',0),(316,3,163,'','Cancelled',NULL,'H13-14',0),(317,3,129,'','Cancelled',NULL,'H13-14',0),(318,3,164,'','Cancelled',NULL,'H13-14',0),(319,3,66,'','Cancelled',NULL,'H13-14',0),(320,3,58,'','Cancelled',NULL,'H13-14',0),(321,3,62,'79:24','Disqualified',NULL,'H13-14',4764),(322,3,134,'118:55','Disqualified',NULL,'H13-14',7135),(323,3,99,'43:25','OK',1038.95,'H15-16',2605),(324,3,105,'44:37','OK',993.96,'H15-16',2677),(325,3,100,'45:20','OK',967.092,'H15-16',2720),(326,3,101,'45:42','OK',953.345,'H15-16',2742),(327,3,103,'46:41','OK',916.479,'H15-16',2801),(328,3,109,'46:41','OK',916.479,'H15-16',2801),(329,3,108,'50:30','OK',773.39,'H15-16',3030),(330,3,107,'50:33','OK',771.515,'H15-16',3033),(331,3,145,'52:00','OK',717.154,'H15-16',3120),(332,3,104,'52:36','OK',694.66,'H15-16',3156),(333,3,155,'54:30','OK',623.427,'H15-16',3270),(334,3,150,'57:03','OK',527.826,'H15-16',3423),(335,3,111,'58:00','OK',492.21,'H15-16',3480),(336,3,165,'58:24','OK',477.214,'H15-16',3504),(337,3,166,'59:56','OK',419.728,'H15-16',3596),(338,3,147,'60:39','OK',392.86,'H15-16',3639),(339,3,112,'67:20','OK',142.298,'H15-16',4040),(340,3,148,'69:02','OK',78.5637,'H15-16',4142),(341,3,110,'69:49','OK',49.196,'H15-16',4189),(342,3,152,'75:03','OK',0,'H15-16',4503),(343,3,151,'75:10','OK',0,'H15-16',4510),(344,3,115,'79:30','OK',0,'H15-16',4770),(345,3,153,'84:16','OK',0,'H15-16',5056),(346,3,106,'','Cancelled',NULL,'H15-16',0),(347,3,102,'','Cancelled',NULL,'H15-16',0),(348,3,118,'36:11','Disqualified',NULL,'H15-16',2171),(349,3,113,'60:04','Disqualified',NULL,'H15-16',3604),(350,3,156,'64:10','Disqualified',NULL,'H15-16',3850),(351,3,146,'66:39','Disqualified',NULL,'H15-16',3999),(352,3,167,'67:16','Disqualified',NULL,'H15-16',4036),(353,3,75,'43:37','OK',1083.29,'D15-16',2617),(354,3,77,'47:01','OK',959.866,'D15-16',2821),(355,3,81,'47:06','OK',956.841,'D15-16',2826),(356,3,73,'50:07','OK',847.33,'D15-16',3007),(357,3,80,'50:52','OK',820.103,'D15-16',3052),(358,3,71,'51:14','OK',806.793,'D15-16',3074),(359,3,94,'51:44','OK',788.641,'D15-16',3104),(360,3,83,'52:05','OK',775.936,'D15-16',3125),(361,3,141,'52:09','OK',773.516,'D15-16',3129),(362,3,168,'52:45','OK',751.734,'D15-16',3165),(363,3,79,'52:56','OK',745.079,'D15-16',3176),(364,3,95,'54:03','OK',704.542,'D15-16',3243),(365,3,72,'54:07','OK',702.122,'D15-16',3247),(366,3,86,'59:27','OK',508.511,'D15-16',3567),(367,3,78,'68:27','OK',181.793,'D15-16',4107),(368,3,90,'69:36','OK',140.045,'D15-16',4176),(369,3,169,'72:20','OK',40.8196,'D15-16',4340),(370,3,144,'74:25','OK',0,'D15-16',4465),(371,3,170,'76:17','OK',0,'D15-16',4577),(372,3,171,'91:01','OK',0,'D15-16',5461),(373,3,96,'','Cancelled',NULL,'D15-16',0),(374,3,74,'','Cancelled',NULL,'D15-16',0),(375,3,89,'','Cancelled',NULL,'D15-16',0),(376,3,93,'20:27','Disqualified',NULL,'D15-16',1227),(377,3,98,'22:09','Disqualified',NULL,'D15-16',1329),(378,3,91,'30:48','Disqualified',NULL,'D15-16',1848),(379,3,143,'55:27','Disqualified',NULL,'D15-16',3327),(380,3,82,'60:05','Disqualified',NULL,'D15-16',3605);
/*!40000 ALTER TABLE `result` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `series`
--

DROP TABLE IF EXISTS `series`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `series` (
  `id` int(11) NOT NULL auto_increment,
  `name` varchar(255) default NULL,
  PRIMARY KEY  (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `series`
--

LOCK TABLES `series` WRITE;
/*!40000 ALTER TABLE `series` DISABLE KEYS */;
INSERT INTO `series` VALUES (1,'Kretsmatch 2012'),(2,'Unionsmatch 2013');
/*!40000 ALTER TABLE `series` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `series_race`
--

DROP TABLE IF EXISTS `series_race`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8 */;
CREATE TABLE `series_race` (
  `id` int(11) NOT NULL auto_increment,
  `series_id` int(11) default NULL,
  `race_id` int(11) default NULL,
  PRIMARY KEY  (`id`),
  KEY `series_id` (`series_id`),
  KEY `race_id` (`race_id`)
) ENGINE=InnoDB AUTO_INCREMENT=5 DEFAULT CHARSET=utf8;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `series_race`
--

LOCK TABLES `series_race` WRITE;
/*!40000 ALTER TABLE `series_race` DISABLE KEYS */;
INSERT INTO `series_race` VALUES (1,1,1),(2,1,2),(3,1,3),(4,2,4);
/*!40000 ALTER TABLE `series_race` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2013-04-29 22:12:16
